////////////////////////////////////////////////////////////////////////////////
//
//         *** Modern C++ Wrappers Around Windows Registry C API ***
//
//       Copyright (C) by Giovanni Dicanio (giovanni.dicanio@gmail.com)
//
//----------------------------------------------------------------------------
// SPDX-License-Identifier: MIT
////////////////////////////////////////////////////////////////////////////////

#pragma once


#include <Windows.h>        // Windows Platform SDK

#include <string>           // std::wstring
#include <string_view>      // std::wstring_view

#include "detail/ScopedLocalFree.hpp"


namespace winreg
{

//------------------------------------------------------------------------------
// A tiny wrapper around LSTATUS return codes used by the Windows Registry API.
//------------------------------------------------------------------------------
class RegResult
{
public:

    // Initialize to success code (ERROR_SUCCESS)
    RegResult() noexcept = default;

    // Initialize with specific Windows Registry API LSTATUS return code
    explicit RegResult(LSTATUS result) noexcept;

    // This class is a tiny C++ object wrapper around an LSTATUS (which is basically
    // a LONG, i.e. a 32-bit integer). So the default copy and move operations
    // are just fine (they will basically copy the 32-bit LSTATUS integer).


    // Is the wrapped code a success code?
    [[nodiscard]] bool IsOk() const noexcept;

    // Is the wrapped error code a failure code?
    [[nodiscard]] bool Failed() const noexcept;

    // Is the wrapped code a success code?
    [[nodiscard]] explicit operator bool() const noexcept;

    // Get the wrapped Win32 code
    [[nodiscard]] LSTATUS Code() const noexcept;

    // Return the system error message associated to the current error code
    [[nodiscard]] std::wstring ErrorMessage() const;

    // Return the system error message associated to the current error code,
    // using the given input language identifier
    [[nodiscard]] std::wstring ErrorMessage(DWORD languageId) const;


    // Just implement equality for RegResult;
    // "ordering error codes" has no real meaning.
    [[nodiscard]] friend bool operator==(const RegResult&, const RegResult&) noexcept = default;


private:
    // Error code returned by Windows Registry C API;
    // default initialized to success code.
    LSTATUS m_result{ ERROR_SUCCESS };
};



//------------------------------------------------------------------------------
//                   RegResult Inline Method Implementation
//------------------------------------------------------------------------------

inline RegResult::RegResult(const LSTATUS result) noexcept
    : m_result{ result }
{
}


inline bool RegResult::IsOk() const noexcept
{
    return m_result == ERROR_SUCCESS;
}


inline bool RegResult::Failed() const noexcept
{
    return m_result != ERROR_SUCCESS;
}


inline RegResult::operator bool() const noexcept
{
    return IsOk();
}


inline LSTATUS RegResult::Code() const noexcept
{
    return m_result;
}


inline std::wstring RegResult::ErrorMessage() const
{
    return ErrorMessage(MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT));
}


inline std::wstring RegResult::ErrorMessage(const DWORD languageId) const
{
    // Invoke FormatMessage() to retrieve the error message from Windows
    detail::ScopedLocalFree<wchar_t> messagePtr;
    const DWORD length = ::FormatMessageW(
        FORMAT_MESSAGE_ALLOCATE_BUFFER |
        FORMAT_MESSAGE_FROM_SYSTEM |
        FORMAT_MESSAGE_IGNORE_INSERTS,
        nullptr,
        m_result,
        languageId,
        reinterpret_cast<LPWSTR>(messagePtr.AddressOf()),
        0,
        nullptr
    );
    if (length == 0)
    {
        // FormatMessage failed: return an empty string
        return std::wstring{};
    }

    // FormatMessage() returns error messages terminating with '\r\n'.
    // Get rid of those characters (and potential other trailing space-like characters, too).
    const std::wstring_view message{ messagePtr.Get(), length };
    const size_t lastNonSpace = message.find_last_not_of(L" \t\r\n");
    if (lastNonSpace == std::wstring_view::npos)
    {
        // This is not expected, as that would mean that the whole string
        // returned by FormatMessage() is made only by spaces...
        return std::wstring{};
    }

    return std::wstring{ message.substr(0, lastNonSpace + 1) };
}


} // namespace winreg

